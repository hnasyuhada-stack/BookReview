<?php
session_start();
require 'db.php'; 

// get and process form data
$username = trim($_POST['username']);
$email = trim($_POST['email']);
$password = password_hash($_POST['password'], PASSWORD_DEFAULT); 

// validate phone format
if (!preg_match('/^1\d{8,9}$/', $phone)) {
    $errors[] = "Invalid phone number format.";
}

// check if email exists
$check = $conn->prepare("SELECT * FROM users WHERE email = ?");
$check->execute([$email]);

if ($check->rowCount() > 0) {
    $_SESSION['register_error'] = "This email is already registered. Please use a different email.";
    header("Location: register.php");
    exit();
}

// insert new user 
$stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
$stmt->execute([$username, $email, $password]);

// redirect with success
$_SESSION['register_success'] = "Registration successful! Please log in.";
header("Location: login.php");
exit();
?>
