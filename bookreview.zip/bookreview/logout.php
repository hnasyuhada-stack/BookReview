<?php
session_start(); // Start the session to access session variables
session_destroy(); // Destroy all session data to log the user out
header("Location: index.php?msg=logout"); // Redirect to the homepage with a logout message
exit();
?>
