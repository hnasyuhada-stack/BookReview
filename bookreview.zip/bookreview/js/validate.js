function validateRegister() {
  const username = document.forms[0]["username"].value.trim();
  const email = document.forms[0]["email"].value.trim();
  const password = document.forms[0]["password"].value.trim();

  if (username.length < 3) {
    alert("Username must be at least 3 characters long.");
    return false;
  }

  if (!email.includes("@") || !email.includes(".")) {
    alert("Please enter a valid email address.");
    return false;
  }

  if (password.length < 6) {
    alert("Password must be at least 6 characters long.");
    return false;
  }

  return true;
}

function validateLogin() {
  const email = document.forms[0]["email"].value.trim();
  const password = document.forms[0]["password"].value.trim();

  if (!email.includes("@") || !email.includes(".")) {
    alert("Please enter a valid email.");
    return false;
  }

  if (password === "") {
    alert("Password cannot be empty.");
    return false;
  }

  return true;
}
