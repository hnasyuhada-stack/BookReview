package com.example.gottools

import android.Manifest
import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.gottools.model.Tool
import com.example.gottools.ui.adapter.ImageAdapter
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*

class AddToolFragment : Fragment() {

    // === Multiple Image Support ===
    private val imageUriList = mutableListOf<Uri>()
    private lateinit var recyclerImages: RecyclerView

    private lateinit var btnAddImage: Button
    private var imageUri: Uri? = null
    private var currentPhotoPath: String? = null

    private val CAMERA_PERMISSION_CODE = 1001
    private val GALLERY_REQUEST_CODE = 1002
    private val CAMERA_REQUEST_CODE = 1003

    private lateinit var inputStartDate: EditText
    private lateinit var inputEndDate: EditText
    private lateinit var inputStartTime: EditText
    private lateinit var inputEndTime: EditText

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_add_tool, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val scrollView = view.findViewById<ScrollView>(R.id.scrollView)

        ViewCompat.setOnApplyWindowInsetsListener(scrollView) { v, insets ->
            val imeHeight = insets.getInsets(WindowInsetsCompat.Type.ime()).bottom
            v.setPadding(0, 0, 0, imeHeight)
            insets
        }

        // 🟡 Scroll to focused EditText when clicked
        val rootView = view.findViewById<LinearLayout>(R.id.linearLayoutContent)
        for (i in 0 until rootView.childCount) {
            val child = rootView.getChildAt(i)
            if (child is EditText) {
                child.setOnFocusChangeListener { v, hasFocus ->
                    if (hasFocus) {
                        scrollView.post {
                            scrollView.smoothScrollTo(0, v.top)
                        }
                    }
                }
            }
        }

        // Continue binding other views
        bindViews(view)
    }

    private fun bindViews(view: View) {
        val inputToolName = view.findViewById<EditText>(R.id.inputTextToolName)
        val spinnerCategory = view.findViewById<Spinner>(R.id.spinnerCategory)
        val spinnerCondition = view.findViewById<Spinner>(R.id.spinnerCondition)
        val spinnerType = view.findViewById<Spinner>(R.id.spinnerType)
        inputStartDate = view.findViewById(R.id.inputStartDate)
        inputEndDate = view.findViewById(R.id.inputEndDate)
        inputStartTime = view.findViewById(R.id.inputStartTime)
        inputEndTime = view.findViewById(R.id.inputEndTime)
        val inputPrice = view.findViewById<EditText>(R.id.inputPrice)
        val inputLocation = view.findViewById<EditText>(R.id.inputLocation)
        val inputUsageGuide = view.findViewById<EditText>(R.id.inputUsageGuide)
        val inputRules = view.findViewById<EditText>(R.id.inputRules)
        val inputCancellationPolicy = view.findViewById<EditText>(R.id.inputCancellationPolicy)
        val switchAutoHide = view.findViewById<Switch>(R.id.switchAutoHide)
        val switchQR = view.findViewById<Switch>(R.id.switchQR)
        val btnSaveTool = view.findViewById<Button>(R.id.btnSaveTool)
        recyclerImages = view.findViewById(R.id.recyclerImages)
        btnAddImage = view.findViewById(R.id.btnAddImage)

        // RecyclerView init
        recyclerImages.layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        recyclerImages.adapter = ImageAdapter(imageUriList) { uri ->
            imageUriList.remove(uri)
            updateImagePreview()
        }

        // Spinners
        val categoryList = listOf(
            "🔌 Electronics & Power Tools",
            "🧰 Hand Tools",
            "🪴 Gardening Tools",
            "🏠 Home Improvement",
            "🪜 Ladders & Access",
            "🧹 Cleaning Tools",
            "🪚 Carpentry & Woodworking",
            "🎨 Painting & Decorating",
            "🛠️ Other / Miscellaneous"
        )
        val typeList = listOf(
            "Rent",      // For a fee, for a period
            "Sell",      // Permanent transfer
            "Swap",      // Exchange for another item
            "Lend",      // Free short-term lending
            "Free"       // Community donation
        )

        val conditionList = listOf(
            "New",
            "Like New",
            "Used",
            "Fixed"
        )

        spinnerCategory.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, categoryList)
        spinnerCondition.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, conditionList)
        spinnerType.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, typeList)

        // Date & Time Pickers
        inputStartDate.setOnClickListener { showDatePicker(inputStartDate) }
        inputEndDate.setOnClickListener { showDatePicker(inputEndDate) }
        inputStartTime.setOnClickListener { showTimePicker(inputStartTime) }
        inputEndTime.setOnClickListener { showTimePicker(inputEndTime) }

        // Image Picker
        btnAddImage.setOnClickListener { showImagePickerOptions() }

        // Save Tool
        btnSaveTool.setOnClickListener {
            val toolName = inputToolName.text.toString().trim()
            val price = inputPrice.text.toString()
            val location = inputLocation.text.toString()

            if (toolName.isEmpty() || price.isEmpty() || location.isEmpty()) {
                Toast.makeText(requireContext(), "Please fill in all required fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val newTool = Tool(
                name = toolName,
                price = price,
                description = inputUsageGuide.text.toString(),
                location = location,
                timeAgo = "Just now",
                isRent = spinnerType.selectedItem.toString() == "Rent",
                userName = "Hana Syuhada",
                imageResId = R.drawable.sample_tool_image
            )

            // TODO: Save tool & imageUriList to Firestore/Storage

            Toast.makeText(requireContext(), "Tool added successfully!", Toast.LENGTH_SHORT).show()
            findNavController().navigateUp()
        }
    }

    private fun showDatePicker(editText: EditText) {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(requireContext(), { _, y, m, d ->
            editText.setText("$d/${m + 1}/$y")
        }, year, month, day)

        datePickerDialog.show()
    }

    private fun showTimePicker(editText: EditText) {
        val calendar = Calendar.getInstance()
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        val minute = calendar.get(Calendar.MINUTE)

        val timePickerDialog = TimePickerDialog(requireContext(), { _, h, m ->
            editText.setText(String.format("%02d:%02d", h, m))
        }, hour, minute, true)

        timePickerDialog.show()
    }

    private fun showImagePickerOptions() {
        val options = arrayOf("Take Photo", "Choose from Gallery")
        val builder = android.app.AlertDialog.Builder(requireContext())
        builder.setTitle("Add Image")
        builder.setItems(options) { _, which ->
            when (which) {
                0 -> openCamera()
                1 -> openGallery()
            }
        }
        builder.show()
    }

    private fun openCamera() {
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(requireActivity(), arrayOf(Manifest.permission.CAMERA), CAMERA_PERMISSION_CODE)
        } else {
            dispatchTakePictureIntent()
        }
    }

    private fun dispatchTakePictureIntent() {
        val takePictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        if (takePictureIntent.resolveActivity(requireActivity().packageManager) != null) {
            val photoFile: File? = try {
                createImageFile()
            } catch (ex: IOException) {
                ex.printStackTrace()
                null
            }

            photoFile?.also {
                val photoURI = FileProvider.getUriForFile(
                    requireContext(),
                    "com.example.gottools.fileprovider",
                    it
                )
                imageUri = photoURI
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
                startActivityForResult(takePictureIntent, CAMERA_REQUEST_CODE)
            }
        }
    }

    private fun createImageFile(): File {
        val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val storageDir: File? = requireContext().getExternalFilesDir(null)
        return File.createTempFile("JPEG_${timeStamp}_", ".jpg", storageDir).apply {
            currentPhotoPath = absolutePath
        }
    }

    private fun openGallery() {
        val intent = Intent(Intent.ACTION_GET_CONTENT)
        intent.type = "image/*"
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        startActivityForResult(Intent.createChooser(intent, "Select Pictures"), GALLERY_REQUEST_CODE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {
                GALLERY_REQUEST_CODE -> {
                    if (data?.clipData != null) {
                        val count = data.clipData!!.itemCount
                        for (i in 0 until count) {
                            val uri = data.clipData!!.getItemAt(i).uri
                            imageUriList.add(uri)
                        }
                    } else if (data?.data != null) {
                        imageUriList.add(data.data!!)
                    }
                    updateImagePreview()
                }
                CAMERA_REQUEST_CODE -> {
                    imageUri?.let { imageUriList.add(it) }
                    updateImagePreview()
                }
            }
        }
    }

    private fun updateImagePreview() {
        recyclerImages.adapter = ImageAdapter(imageUriList) { uri ->
            imageUriList.remove(uri)
            updateImagePreview()
        }
    }
}