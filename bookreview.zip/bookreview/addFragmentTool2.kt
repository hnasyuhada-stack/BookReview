package com.example.gottools

import android.Manifest
import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.gottools.model.Tool
import com.example.gottools.ui.adapter.ImageAdapter
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*
import android.location.Location
import android.location.LocationManager
import android.location.LocationListener
import android.os.Looper
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.LocationRequest
import com.google.android.material.textfield.TextInputLayout

class AddToolFragment : Fragment() {

    // === Multiple Images Support for main tool images ===
    private val imageUriList = mutableListOf<Uri>()
    private lateinit var recyclerImages: RecyclerView
    private lateinit var btnAddImage: Button
    private var imageUri: Uri? = null
    private var currentPhotoPath: String? = null

    // === Multiple Images Support for Usage Guide ===
    private val usageImageUris = mutableListOf<Uri>()
    private lateinit var recyclerUsageImages: RecyclerView
    private lateinit var btnAddUsageImage: Button

    private val CAMERA_PERMISSION_CODE = 1001
    private val GALLERY_REQUEST_CODE = 1002
    private val CAMERA_REQUEST_CODE = 1003
    private val GALLERY_USAGE_CODE = 9001

    private lateinit var inputStartDate: EditText
    private lateinit var inputEndDate: EditText
    private lateinit var inputStartTime: EditText
    private lateinit var inputEndTime: EditText

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var btnUseMyLocation: Button

    // Firebase
    private val firestore = FirebaseFirestore.getInstance()
    private val storageRef = FirebaseStorage.getInstance().reference

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_add_tool, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(requireContext())

        val scrollView = view.findViewById<ScrollView>(R.id.scrollView)
        ViewCompat.setOnApplyWindowInsetsListener(scrollView) { v, insets ->
            val imeHeight = insets.getInsets(WindowInsetsCompat.Type.ime()).bottom
            v.setPadding(0, 0, 0, imeHeight)
            insets
        }

        bindViews(view)
    }

    private fun bindViews(view: View) {
        val inputToolName = view.findViewById<EditText>(R.id.inputTextToolName)
        val spinnerCategory = view.findViewById<Spinner>(R.id.spinnerCategory)
        val spinnerCondition = view.findViewById<Spinner>(R.id.spinnerCondition)
        val spinnerType = view.findViewById<Spinner>(R.id.spinnerType)
        inputStartDate = view.findViewById(R.id.inputStartDate)
        inputEndDate = view.findViewById(R.id.inputEndDate)
        inputStartTime = view.findViewById(R.id.inputStartTime)
        inputEndTime = view.findViewById(R.id.inputEndTime)
        val inputPrice = view.findViewById<EditText>(R.id.inputPrice)
        val inputSwapItem = view.findViewById<EditText>(R.id.inputSwapItem) // NEW field for swap item
        val inputUsageGuide = view.findViewById<EditText>(R.id.inputUsageGuide)
        val inputRules = view.findViewById<EditText>(R.id.inputRules)
        val inputCancellationPolicy = view.findViewById<EditText>(R.id.inputCancellationPolicy)
        val switchAutoHide = view.findViewById<Switch>(R.id.switchAutoHide)
        val switchQR = view.findViewById<Switch>(R.id.switchQR)
        val btnSaveTool = view.findViewById<Button>(R.id.btnSaveTool)
        recyclerImages = view.findViewById(R.id.recyclerImages)
        btnAddImage = view.findViewById(R.id.btnAddImage)
        val inputLocation = view.findViewById<EditText>(R.id.inputLocation)
        val dropdownPopularLocations = view.findViewById<AutoCompleteTextView>(R.id.dropdownPopularLocations)
        btnUseMyLocation = view.findViewById(R.id.btnUseMyLocation)
        val layoutSwapItem = view.findViewById<TextInputLayout>(R.id.layoutSwapItem)


        // === Popular location (AutoCompleteTextView) ===
        val popularLocations = listOf(
            "Surau Al-Taqwa",
            "Dewan Bunga Kemboja",
            "Playground U11/4",
            "Bukit Bandaraya Guardhouse"
        )
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_dropdown_item_1line, popularLocations)
        dropdownPopularLocations.setAdapter(adapter)
        dropdownPopularLocations.setOnItemClickListener { _, _, position, _ ->
            inputLocation.setText(popularLocations[position])
        }

        // === GPS Button ===
        btnUseMyLocation.setOnClickListener {
            if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    requireActivity(),
                    arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                    1234
                )
            } else {
                fusedLocationClient.lastLocation
                    .addOnSuccessListener { location: Location? ->
                        if (location != null) {
                            val lat = location.latitude
                            val lng = location.longitude
                            inputLocation.setText("$lat, $lng")
                        } else {
                            Toast.makeText(requireContext(), "Unable to get location", Toast.LENGTH_SHORT).show()
                        }
                    }
            }
        }

        // === Hide Price & toggle Swap Item field ===
        spinnerType.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                val selected = parent.getItemAtPosition(position).toString()

                inputPrice.visibility = if (selected == "Free" || selected == "Lend" || selected == "Swap") {
                    View.GONE
                } else {
                    View.VISIBLE
                }

                layoutSwapItem.visibility = if (selected == "Swap") {
                    View.VISIBLE
                } else {
                    View.GONE
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        // === Usage Guide images ===
        btnAddUsageImage = view.findViewById(R.id.btnAddUsageImage)
        recyclerUsageImages = view.findViewById(R.id.recyclerUsageImages)
        recyclerUsageImages.layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        recyclerUsageImages.adapter = ImageAdapter(usageImageUris) { uri ->
            usageImageUris.remove(uri)
            updateUsageImagePreview()
        }
        btnAddUsageImage.setOnClickListener { openGalleryForUsageImages() }

        // === Main tool images ===
        recyclerImages.layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        recyclerImages.adapter = ImageAdapter(imageUriList) { uri ->
            imageUriList.remove(uri)
            updateImagePreview()
        }

        val categoryList = listOf(
            "Select a category...",
            "🔌 Electronics & Power Tools",
            "🧰 Hand Tools",
            "🪴 Gardening Tools",
            "🏠 Home Improvement",
            "🪜 Ladders & Access",
            "🧹 Cleaning Tools",
            "🪚 Carpentry & Woodworking",
            "🎨 Painting & Decorating",
            "🛠️ Other / Miscellaneous"
        )

        val conditionList = listOf(
            "Select condition...",
            "New", "Like New", "Used", "Fixed"
        )

        val typeList = listOf(
            "Select listing type...",
            "Rent", "Sell", "Swap", "Lend", "Free"
        )

        spinnerCategory.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, categoryList)
        spinnerCondition.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, conditionList)
        spinnerType.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, typeList)

        // Date & time pickers
        inputStartDate.setOnClickListener { showDatePicker(inputStartDate) }
        inputEndDate.setOnClickListener { showDatePicker(inputEndDate) }
        inputStartTime.setOnClickListener { showTimePicker(inputStartTime) }
        inputEndTime.setOnClickListener { showTimePicker(inputEndTime) }

        // Image pickers
        btnAddImage.setOnClickListener { showImagePickerOptions() }

        // Save Tool
        btnSaveTool.setOnClickListener {
            val toolName = inputToolName.text.toString().trim()
            val price = inputPrice.text.toString()
            val swapItem = inputSwapItem.text.toString().trim()
            val location = inputLocation.text.toString()
            val selectedCategory = spinnerCategory.selectedItem.toString()
            val selectedCondition = spinnerCondition.selectedItem.toString()
            val selectedType = spinnerType.selectedItem.toString()

            if (toolName.isEmpty() ||
                (selectedType != "Free" && selectedType != "Lend" && selectedType != "Swap" && price.isEmpty()) ||
                (selectedType == "Swap" && swapItem.isEmpty()) ||
                location.isEmpty() ||
                selectedCategory.startsWith("Select") ||
                selectedCondition.startsWith("Select") ||
                selectedType.startsWith("Select")
            ) {
                Toast.makeText(requireContext(), "Please fill in all required fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val toolDoc = hashMapOf(
                "name" to toolName,
                "price" to price,
                "swapItem" to swapItem, // saved in Firestore
                "description" to inputUsageGuide.text.toString(),
                "location" to location,
                "rules" to inputRules.text.toString(),
                "cancelPolicy" to inputCancellationPolicy.text.toString(),
                "category" to spinnerCategory.selectedItem.toString(),
                "condition" to spinnerCondition.selectedItem.toString(),
                "listingType" to spinnerType.selectedItem.toString(),
                "autoHide" to switchAutoHide.isChecked,
                "qrPickup" to switchQR.isChecked,
                "timeAgo" to "Just now",
                "userName" to "Hana Syuhada"
            )

            val docRef = firestore.collection("tools").document()
            docRef.set(toolDoc)
                .addOnSuccessListener {
                    uploadImagesToFirebase(docRef.id)
                    Toast.makeText(requireContext(), "Tool added successfully!", Toast.LENGTH_SHORT).show()
                    findNavController().navigateUp()
                }
                .addOnFailureListener {
                    Toast.makeText(requireContext(), "Error saving tool: ${it.message}", Toast.LENGTH_SHORT).show()
                }
        }
    }

    private fun uploadImagesToFirebase(toolId: String) {
        for ((index, uri) in usageImageUris.withIndex()) {
            val usageRef = storageRef.child("tools/$toolId/usage_image_$index.jpg")
            usageRef.putFile(uri)
        }
        for ((index, uri) in imageUriList.withIndex()) {
            val imgRef = storageRef.child("tools/$toolId/image_$index.jpg")
            imgRef.putFile(uri)
        }
    }

    private fun openGalleryForUsageImages() {
        val intent = Intent(Intent.ACTION_GET_CONTENT)
        intent.type = "image/*"
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        startActivityForResult(Intent.createChooser(intent, "Select Usage Guide Images"), GALLERY_USAGE_CODE)
    }

    private fun showDatePicker(editText: EditText) {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)
        DatePickerDialog(requireContext(), { _, y, m, d ->
            editText.setText("$d/${m + 1}/$y")
        }, year, month, day).show()
    }

    private fun showTimePicker(editText: EditText) {
        val calendar = Calendar.getInstance()
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        val minute = calendar.get(Calendar.MINUTE)
        TimePickerDialog(requireContext(), { _, h, m ->
            editText.setText(String.format("%02d:%02d", h, m))
        }, hour, minute, true).show()
    }

    private fun showImagePickerOptions() {
        val options = arrayOf("Take Photo", "Choose from Gallery")
        val builder = android.app.AlertDialog.Builder(requireContext())
        builder.setTitle("Add Image")
        builder.setItems(options) { _, which ->
            when (which) {
                0 -> openCamera()
                1 -> openGallery()
            }
        }
        builder.show()
    }

    private fun openCamera() {
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(requireActivity(), arrayOf(Manifest.permission.CAMERA), CAMERA_PERMISSION_CODE)
        } else {
            dispatchTakePictureIntent()
        }
    }

    private fun dispatchTakePictureIntent() {
        val takePictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        if (takePictureIntent.resolveActivity(requireActivity().packageManager) != null) {
            val photoFile: File? = try {
                createImageFile()
            } catch (ex: IOException) {
                ex.printStackTrace()
                null
            }
            photoFile?.also {
                val photoURI = FileProvider.getUriForFile(
                    requireContext(),
                    "com.example.gottools.fileprovider",
                    it
                )
                imageUri = photoURI
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
                startActivityForResult(takePictureIntent, CAMERA_REQUEST_CODE)
            }
        }
    }

    private fun createImageFile(): File {
        val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val storageDir: File? = requireContext().getExternalFilesDir(null)
        return File.createTempFile("JPEG_${timeStamp}_", ".jpg", storageDir).apply {
            currentPhotoPath = absolutePath
        }
    }

    private fun openGallery() {
        val intent = Intent(Intent.ACTION_GET_CONTENT)
        intent.type = "image/*"
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        startActivityForResult(Intent.createChooser(intent, "Select Pictures"), GALLERY_REQUEST_CODE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {
                GALLERY_REQUEST_CODE -> {
                    if (data?.clipData != null) {
                        val count = data.clipData!!.itemCount
                        for (i in 0 until count) {
                            val uri = data.clipData!!.getItemAt(i).uri
                            imageUriList.add(uri)
                        }
                    } else if (data?.data != null) {
                        imageUriList.add(data.data!!)
                    }
                    updateImagePreview()
                }
                CAMERA_REQUEST_CODE -> {
                    imageUri?.let { imageUriList.add(it) }
                    updateImagePreview()
                }
                GALLERY_USAGE_CODE -> {
                    if (data?.clipData != null) {
                        val count = data.clipData!!.itemCount
                        for (i in 0 until count) {
                            val uri = data.clipData!!.getItemAt(i).uri
                            usageImageUris.add(uri)
                        }
                    } else if (data?.data != null) {
                        usageImageUris.add(data.data!!)
                    }
                    updateUsageImagePreview()
                }
            }
        }
    }

    private fun updateImagePreview() {
        if (imageUriList.isEmpty()) {
            recyclerImages.animate().alpha(0f).setDuration(200).withEndAction {
                recyclerImages.visibility = View.GONE
            }.start()
        } else {
            recyclerImages.visibility = View.VISIBLE
            recyclerImages.alpha = 0f
            recyclerImages.adapter = ImageAdapter(imageUriList) { uri ->
                imageUriList.remove(uri)
                updateImagePreview()
            }
            recyclerImages.animate().alpha(1f).setDuration(200).start()
        }
    }

    private fun updateUsageImagePreview() {
        if (usageImageUris.isEmpty()) {
            recyclerUsageImages.animate().alpha(0f).setDuration(200).withEndAction {
                recyclerUsageImages.visibility = View.GONE
            }.start()
        } else {
            recyclerUsageImages.visibility = View.VISIBLE
            recyclerUsageImages.alpha = 0f
            recyclerUsageImages.adapter = ImageAdapter(usageImageUris) { uri ->
                usageImageUris.remove(uri)
                updateUsageImagePreview()
            }
            recyclerUsageImages.animate().alpha(1f).setDuration(200).start()
        }
    }

    private fun uploadImagesToFirebase(toolId: String) {
        val imageUrls = mutableListOf<String>()
        val usageUrls = mutableListOf<String>()


        val totalImages = imageUriList.size + usageImageUris.size
        var uploadedCount = 0


        val onComplete = {
// Update Firestore with image URLs once all uploads done
            firestore.collection("tools").document(toolId)
                .update(
                    mapOf(
                        "imageUrls" to imageUrls,
                        "usageGuideImages" to usageUrls
                    )
                )
                .addOnSuccessListener {
                    Toast.makeText(requireContext(), "Tool uploaded with images!", Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener {
                    Toast.makeText(requireContext(), "Image URL save error: ${it.message}", Toast.LENGTH_SHORT).show()
                }
        }


        fun checkAndFinish() {
            uploadedCount++
            if (uploadedCount == totalImages) onComplete()
        }


        for ((index, uri) in imageUriList.withIndex()) {
            val imgRef = storageRef.child("tools/$toolId/image_$index.jpg")
            imgRef.putFile(uri)
                .continueWithTask { task ->
                    if (!task.isSuccessful) throw task.exception ?: Exception("Upload failed")
                    imgRef.downloadUrl
                }
                .addOnSuccessListener { uri ->
                    imageUrls.add(uri.toString())
                    checkAndFinish()
                }
                .addOnFailureListener {
                    Toast.makeText(requireContext(), "Failed to upload image: ${it.message}", Toast.LENGTH_SHORT).show()
                    checkAndFinish()
                }
        }


        for ((index, uri) in usageImageUris.withIndex()) {
            val usageRef = storageRef.child("tools/$toolId/usage_image_$index.jpg")
            usageRef.putFile(uri)
                .continueWithTask { task ->
                    if (!task.isSuccessful) throw task.exception ?: Exception("Upload failed")
                    usageRef.downloadUrl
                }
                .addOnSuccessListener { uri ->
                    usageUrls.add(uri.toString())
                    checkAndFinish()
                }
                .addOnFailureListener {
                    Toast.makeText(requireContext(), "Failed to upload usage image: ${it.message}", Toast.LENGTH_SHORT).show()
                    checkAndFinish()
                }
        }


// If there are no images at all
        if (totalImages == 0) onComplete()
    }
}
