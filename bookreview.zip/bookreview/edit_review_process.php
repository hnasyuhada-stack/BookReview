<?php
session_start();
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['user_id'])) {
  $review_id = (int)$_POST['review_id'];
  $rating = (int)$_POST['rating'];
  $comment = trim($_POST['comment']);
  $user_id = $_SESSION['user_id'];

  // fetch book_id for redirect
  $get = $conn->prepare("SELECT book_id FROM reviews WHERE review_id = ? AND user_id = ?");
  $get->execute([$review_id, $user_id]);
  $book_id = $get->fetchColumn();

  if ($book_id) {
    $stmt = $conn->prepare("UPDATE reviews SET rating = ?, comment = ? WHERE review_id = ? AND user_id = ?");
    $stmt->execute([$rating, $comment, $review_id, $user_id]);

  header("Location: index.php?page=book_details&id=$book_id&msg=edited");
  exit;
}
}
?>
