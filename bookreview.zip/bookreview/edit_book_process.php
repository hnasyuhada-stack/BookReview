<?php
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $book_id = intval($_POST['book_id']);
  $title = trim($_POST['title']);
  $author = trim($_POST['author']);
  $genre = trim($_POST['genre']);
  $year = intval($_POST['year']);
  $description = trim($_POST['description']);

  $errors = [];

  if (strlen($title) < 2) $errors[] = "Title must be at least 2 characters.";
  if (strlen($author) < 2) $errors[] = "Author must be at least 2 characters.";
  if (!empty($year) && ($year < 1000 || $year > 2099)) $errors[] = "Year must be between 1000 and 2099.";

  //fetch existing image
  $stmt = $conn->prepare("SELECT cover_image FROM books WHERE book_id = ?");
  $stmt->execute([$book_id]);
  $book = $stmt->fetch(PDO::FETCH_ASSOC);
  $imageName = $book['cover_image'];

  //handle new image upload
  if (!empty($_FILES["cover_image"]["name"])) {
    $targetDir = "images/covers/";
    if (!is_dir($targetDir)) mkdir($targetDir, 0755, true);

    $imageName = basename($_FILES["cover_image"]["name"]);
    $targetFilePath = $targetDir . $imageName;

    if (!move_uploaded_file($_FILES["cover_image"]["tmp_name"], $targetFilePath)) {
      $errors[] = "Failed to upload the new image.";
    }
  }

  if (!empty($errors)) {
    foreach ($errors as $e) {
      echo "<p style='color:red;'>$e</p>";
    }
    echo "<p><a href='index.php?page=edit_book&id=$book_id'>Go back</a></p>";
    exit();
  }

  //update book record
  $update = $conn->prepare("UPDATE books SET title = ?, author = ?, genre = ?, year = ?, description = ?, cover_image = ? WHERE book_id = ?");
  $update->execute([$title, $author, $genre, $year, $description, $imageName, $book_id]);

  //success alert and redirect
  echo "<script>
    alert('Book updated successfully!');
    window.location.href = 'index.php?page=view_books';
  </script>";
  exit();
}
?>
