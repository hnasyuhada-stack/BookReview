<?php
require 'db.php';
session_start();

//get login credentials
$email = $_POST['email'];
$password = $_POST['password'];

//find user by email
$stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
$stmt->execute([$email]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

//verify password
if ($user && password_verify($password, $user['password'])) {
    $_SESSION['user_id'] = $user['user_id'];
    $_SESSION['username'] = $user['username'];
    header("Location: index.php");
} else {
    $_SESSION['login_error'] = "Invalid email or password. Please try again or register.";
    header("Location: login.php");
}
exit();
