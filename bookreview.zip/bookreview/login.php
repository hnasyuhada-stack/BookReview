<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
  <title>Login</title>
  <link rel="stylesheet" href="css/style.css">
  <style>
    body {
      background-color: #f4f4f4;
      font-family: Arial, sans-serif;
    }

    .page-title {
      text-align: center;
      margin: 40px 0 20px;
      font-size: 28px;
      color: #2c3e50;
    }

    .form-card {
      display: flex;
      align-items: center;
      justify-content: center;
      background: #fff;
      padding: 30px;
      border-radius: 10px;
      max-width: 800px;
      margin: auto;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
      gap: 30px;
      flex-wrap: wrap;
    }

    .form-left img {
      width: 300px;
      border-radius: 8px;
    }

    .form-right {
      flex: 1;
      min-width: 250px;
    }

    .form-right label {
      font-weight: bold;
      display: block;
      margin-top: 15px;
    }

    .form-right input {
      width: 100%;
      padding: 10px;
      margin-top: 5px;
      border: 1px solid #ccc;
      border-radius: 4px;
      background-color: #eef6ff;
    }

    .form-right button {
      width: 100%;
      margin-top: 20px;
      background-color: #28a745;
      color: white;
      padding: 10px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    .form-right button:hover {
      background-color: #218838;
    }

    .register-link {
      text-align: center;
      margin-top: 20px;
      font-size: 14px;
    }

    .register-link a {
      color: #007bff;
      text-decoration: none;
    }

    .register-link a:hover {
      text-decoration: underline;
    }
    .error-msg {
      background-color: #f8d7da;
      color: #721c24;
      border: 1px solid #f5c6cb;
      border-radius: 5px;
      padding: 10px 20px;
      max-width: 600px;
      margin: 20px auto;
      font-weight: bold;
      text-align: center;
    }
       .success-msg {
      background-color: #d4edda;
      color: #155724;
      border: 1px solid #c3e6cb;
      border-radius: 5px;
      padding: 10px 20px;
      max-width: 600px;
      margin: 20px auto;
      font-weight: bold;
      text-align: center;
    }

  </style>
</head>
<body>
<?php if (isset($_SESSION['login_error'])): ?>
  <div class="error-msg">
    <?= $_SESSION['login_error'] ?>
  </div>
  <?php unset($_SESSION['login_error']); ?>
<?php endif; ?>
<?php
if (isset($_SESSION['register_success'])) {
    echo "<div class='success-msg'>" . $_SESSION['register_success'] . "</div>";
    unset($_SESSION['register_success']);
}
?>

<h2 class="page-title">Login to Book Review Platform</h2>
<div class="form-card">
  <div class="form-left">
    <img src="images/bookreview.jpg" alt="Book Review Image">
  </div>

  <div class="form-right">
    <form method="post" action="login_process.php">
      <label for="email">Email:</label>
      <input type="email" name="email" id="email" required>

      <label for="password">Password:</label>
      <div style="position:relative;">
        <input type="password" name="password" id="password" required style="padding-right:60px;">
        <span id="togglePassword" onclick="togglePassword()" style="
            position: absolute;
            right: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: #3498db;
            cursor: pointer;
            font-size: 15px;
            user-select: none;
            font-weight: 500;">Show</span>
      </div>

      <button type="submit">Login</button>
    </form>
    <div class="register-link">
      Don't have an account? <a href="register.php">Register here</a>.
    </div>
  </div>
</div>
<script>
//JS toggle password visibility
function togglePassword() {
  const passwordInput = document.getElementById("password");
  const toggleLabel = document.getElementById("togglePassword");
  if (passwordInput.type === "password") {
    passwordInput.type = "text";
    toggleLabel.textContent = "Hide";
  } else {
    passwordInput.type = "password";
    toggleLabel.textContent = "Show";
  }
}
</script>

</body>
</html>
