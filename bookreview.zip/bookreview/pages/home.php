<?php
require 'db.php';

// get all books
$stmt = $conn->query("SELECT * FROM books ORDER BY book_id DESC ");
$recentBooks = $stmt->fetchAll(PDO::FETCH_ASSOC);

// get the total number of books
$totalBooks = count($recentBooks);

// count total books
$stmt = $conn->query("SELECT COUNT(*) FROM books");
$totalBooks = $stmt->fetchColumn();

// count total users
$stmt = $conn->query("SELECT COUNT(*) FROM users");
$totalUsers = $stmt->fetchColumn();
?>

<div class="counter-section">
  <div class="counter-box">
    <div class="counter-number"><?= $totalBooks ?></div>
    <div class="counter-label">BOOKS</div>
  </div>
  <div class="counter-box">
    <div class="counter-number"><?= $totalUsers ?></div>
    <div class="counter-label">USERS</div>
  </div>
</div>


<p class="section-subtitle">Explore all available books below:</p>

<div class="card-container">
  <?php foreach ($recentBooks as $book): ?>
    <div class="book-card">
      <?php if (!empty($book['cover_image'])): ?>
        <div class="cover-wrapper">
          <img src="images/covers/<?= htmlspecialchars($book['cover_image']) ?>" alt="Cover">
        </div>
      <?php endif; ?>

      <h3 class="book-title"><?= htmlspecialchars($book['title']) ?></h3>
      <p><strong>Author:</strong> <?= htmlspecialchars($book['author']) ?></p>
      <p><strong>Genre:</strong> <?= htmlspecialchars($book['genre']) ?></p>
      <div style="text-align: center; margin-top: 10px;">
        <a href="index.php?page=book_details&id=<?= $book['book_id'] ?>" class="link-more">Read More</a>
      </div>
    </div>
  <?php endforeach; ?>
</div>
