<?php 
require 'db.php';

$book_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// get book info
$stmt = $conn->prepare("SELECT * FROM books WHERE book_id = ?");
$stmt->execute([$book_id]);
$book = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$book) {
  echo "<p>Book not found.</p>";
  return;
}

// show review action messages here:
$msg = '';
if (isset($_GET['msg'])) {
    if ($_GET['msg'] == 'added') $msg = "Review added successfully!";
    if ($_GET['msg'] == 'edited') $msg = "Review updated successfully!";
    if ($_GET['msg'] == 'deleted') $msg = "Review deleted successfully!";
}
if ($msg) {
    echo '<div style="background:#d4edda;color:#155724;padding:12px;border-radius:4px;margin:10px 0;">'.$msg.'</div>';
}

// get reviews for this book
$reviewStmt = $conn->prepare("
  SELECT r.*, u.username 
  FROM reviews r 
  JOIN users u ON r.user_id = u.user_id 
  WHERE r.book_id = ?
  ORDER BY r.created_at DESC
");
$reviewStmt->execute([$book_id]);
$reviews = $reviewStmt->fetchAll(PDO::FETCH_ASSOC);
?>


<div class="book-details">
  <h2 class="book-title"><?= htmlspecialchars($book['title']) ?></h2>

  <?php if ($book['cover_image']): ?>
    <div class="cover-wrapper" style="text-align:center; margin-bottom: 15px;">
      <img src="images/covers/<?= htmlspecialchars($book['cover_image']) ?>" alt="Book Cover" class="book-cover" style="max-width: 200px; border-radius: 8px;">
    </div>
  <?php endif; ?>

  <p><strong>Author:</strong> <?= htmlspecialchars($book['author']) ?></p>
  <p><strong>Genre:</strong> <?= htmlspecialchars($book['genre']) ?></p>
  <p><strong>Year:</strong> <?= $book['year'] ?></p>
  <p class="book-desc"><?= nl2br(htmlspecialchars($book['description'])) ?></p>
</div>

<hr>

<div class="review-section">
  <div class="review-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
    <h3 style="margin: 0;">📝 Reviews</h3>

    <?php if (isset($_SESSION['user_id'])): ?>
      <a class="btn-small" href="index.php?page=add_review&book_id=<?= $book_id ?>">+ Add a Review</a>
    <?php endif; ?>
  </div>

  <?php if (!isset($_SESSION['user_id'])): ?>
    <p><em>You must log in to add a review.</em></p>
  <?php endif; ?>

  <?php if (count($reviews) === 0): ?>
    <p>No reviews yet.</p>
  <?php else: ?>
    <?php foreach ($reviews as $r): ?>
      <div class="review-card">
        <?php
          $stars = str_repeat('⭐', $r['rating']) . str_repeat('☆', 5 - $r['rating']);
        ?>
        <p><strong><?= htmlspecialchars($r['username']) ?></strong> <span class="stars"><?= $stars ?></span> (<?= $r['rating'] ?>/5)</p>
        <p><?= nl2br(htmlspecialchars($r['comment'])) ?></p>
        <?php if (isset($_SESSION['user_id']) && $_SESSION['user_id'] == $r['user_id']): ?>
          <div class="review-actions">
            <a class="btn-edit" href="index.php?page=edit_review&id=<?= $r['review_id'] ?>">✏️ Edit</a>
            <a class="btn-delete" href="delete_review.php?id=<?= $r['review_id'] ?>&book_id=<?= $book_id ?>" onclick="return confirm('Delete this review?')">🗑️ Delete</a>
          </div>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>
</div>

<p><a class="back-link" href="index.php">&larr; Back to Home</a></p>
