<?php
require 'db.php';

if (!isset($_SESSION['user_id'])) {
  echo "<p>You must be logged in to write a review.</p>";
  echo "<p><a href='login.php'>Login</a></p>";
  return;
}

if (!isset($_GET['book_id'])) {
  echo "<p>Invalid book ID.</p>";
  return;
}

$book_id = (int)$_GET['book_id'];
$user_id = $_SESSION['user_id'];

// check if user already reviewed this book
$check = $conn->prepare("SELECT * FROM reviews WHERE book_id = ? AND user_id = ?");
$check->execute([$book_id, $user_id]);

if ($check->rowCount() > 0) {
  echo "<script>
    alert('You’ve already submitted a review for this book.');
    window.location.href = 'index.php?page=book_details&id=$book_id';
  </script>";
  exit;
}

?>

<h2 class="page-title">Write a Review</h2>

<div class="form-card">
  <form method="post" action="add_review_process.php" class="review-form">
    <input type="hidden" name="book_id" value="<?= $book_id ?>">

    <label for="rating">Rating (1-5):</label>
    <input type="number" name="rating" id="rating" min="1" max="5" required>

    <label for="comment">Comment:</label>
    <textarea name="comment" id="comment" required></textarea>

    <button type="submit" class="btn">Submit Review</button>
  </form>
</div>

<p><a href="index.php?page=book_details&id=<?= $book_id ?>" class="back-link">&larr; Back to Book</a></p>
