<?php
require 'db.php';

if (!isset($_GET['id']) || !isset($_SESSION['user_id'])) {
  echo "<p class='error-msg'>Unauthorized access.</p>";
  return;
}

$review_id = (int)$_GET['id'];
$user_id = $_SESSION['user_id'];

$stmt = $conn->prepare("SELECT * FROM reviews WHERE review_id = ? AND user_id = ?");
$stmt->execute([$review_id, $user_id]);
$review = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$review) {
  echo "<p class='error-msg'>Review not found or you're not authorized.</p>";
  return;
}

$book_id = $review['book_id'];
?>

<h2 class="page-title">✏️ Edit Your Review</h2>

<form method="post" action="edit_review_process.php" class="review-form no-shadow">
  <input type="hidden" name="review_id" value="<?= $review_id ?>">

  <label for="rating">Rating (1-5):</label>
  <input type="number" id="rating" name="rating" value="<?= $review['rating'] ?>" min="1" max="5" required>

  <label for="comment">Comment:</label>
  <textarea id="comment" name="comment" required><?= htmlspecialchars($review['comment']) ?></textarea>

  <button type="submit" class="btn">Update Review</button>
</form>

<p style="text-align: center;">
  <a class="back-link" href="index.php?page=book_details&id=<?= $book_id ?>">&larr; Back to Book</a>
</p>
