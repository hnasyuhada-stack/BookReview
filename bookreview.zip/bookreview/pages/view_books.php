<?php
require 'db.php';

// make sure user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id']; // get current user id

// search 
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$sort = 'title';

// sort by book_id DESC (latest first)
$sort = 'book_id';

// only show books that belong to the logged-in user
$query = $conn->prepare("SELECT * FROM books 
    WHERE user_id = ? 
      AND (title LIKE ? OR author LIKE ? OR year LIKE ? OR genre LIKE ?)
    ORDER BY $sort DESC");
$query->execute([$user_id, "%$search%", "%$search%", "%$search%", "%$search%"]);

$books = $query->fetchAll(PDO::FETCH_ASSOC);
?>

<?php if (isset($_GET['deleted']) && $_GET['deleted'] == '1'): ?>
  <script>
    alert("Book deleted successfully.");
  </script>
<?php endif; ?>

<h2 class="section-title">📚 Book List</h2>

<div class="add-book-link">
  <a href="index.php?page=add_book" class="btn small-btn">+ Add New Book</a>
</div>

<?php if (count($books) === 0): ?>
  <p>No books found.</p>
<?php else: ?>
  <table class="book-table">
    <thead>
      <tr>
        <th>Cover</th>
        <th>Title</th>
        <th>Author</th>
        <th>Genre</th>
        <th>Year</th>
        <th>Description</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($books as $book): ?>
        <tr>
          <td>
            <?php if (!empty($book['cover_image'])): ?>
              <img src="images/covers/<?= htmlspecialchars($book['cover_image']) ?>" alt="Cover" style="width:60px; height:auto; border-radius:4px;">
            <?php else: ?>
              No Image
            <?php endif; ?>
          </td>
          <td><?= htmlspecialchars($book['title']) ?></td>
          <td><?= htmlspecialchars($book['author']) ?></td>
          <td><?= htmlspecialchars($book['genre']) ?></td>
          <td><?= $book['year'] ?></td>
          <td><?= nl2br(htmlspecialchars($book['description'])) ?></td>
          <td class="action-cell">
            <div class="action-buttons">
              <a href="index.php?page=edit_book&id=<?= $book['book_id'] ?>" class="btn btn-edit">✏️ Edit</a>
              <a href="delete_book.php?id=<?= $book['book_id'] ?>&redirect=view_books" class="btn btn-delete" onclick="return confirm('Are you sure?')">🗑️ Delete</a>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
<?php endif; ?>
