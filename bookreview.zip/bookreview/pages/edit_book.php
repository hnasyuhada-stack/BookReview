<?php
require 'db.php';

if (!isset($_GET['id'])) {
  echo "<p>Book ID is missing.</p>";
  return;
}

$book_id = $_GET['id'];
$stmt = $conn->prepare("SELECT * FROM books WHERE book_id = ?");
$stmt->execute([$book_id]);
$book = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$book) {
  echo "<p>Book not found.</p>";
  return;
}
?>

<h2 class="page-title">✏️ Edit Book Details</h2>

<form method="post" action="edit_book_process.php" enctype="multipart/form-data">
  <input type="hidden" name="book_id" value="<?= $book['book_id'] ?>">

  <label>Title:</label>
  <input type="text" name="title" value="<?= htmlspecialchars($book['title']) ?>" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px;">

  <label>Author:</label>
  <input type="text" name="author" value="<?= htmlspecialchars($book['author']) ?>" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px;">

  <div style="display: flex; gap: 20px;">
    <div style="flex: 1;">
      <label for="genre">Genre:</label>
      <select name="genre" id="genre" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px;">
        <option value="">-- Select Genre --</option>
        <?php
          $genres = [
            "Fantasy", "Science Fiction", "Fantasy Thriller", "Mystery Thriller", "Dark Fantasy",
            "Gothic Fiction", "Non-Fiction", "Children’s Fiction", "Sci-Fi Adventure", "Dystopian Sci-Fi"
          ];
          foreach ($genres as $genreOption) {
            $selected = ($book['genre'] === $genreOption) ? 'selected' : '';
            echo "<option value=\"$genreOption\" $selected>$genreOption</option>";
          }
        ?>
      </select>
    </div>

    <div style="flex: 1;">
      <label for="year">Year:</label>
      <input type="number" name="year" id="year" min="1000" max="2099" value="<?= $book['year'] ?>" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px;">
    </div>
  </div>

  <label>Description:</label>
  <textarea name="description" rows="4" required
    style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; background-color: #eef6ff;">
    <?= htmlspecialchars($book['description']) ?>
  </textarea>

  <?php if (!empty($book['cover_image'])): ?>
    <div style="display: flex; align-items: center; gap: 15px; margin-top: 20px;">
      <p style="margin: 0;"><strong>Current Image:</strong></p>
      <img src="images/covers/<?= htmlspecialchars($book['cover_image']) ?>" alt="Current Cover" style="width: 120px; height: auto; border: 1px solid #ccc; border-radius: 4px;">
    </div>
  <?php endif; ?>

  <label style="margin-top: 20px;">Change Cover Image:</label>
  <input type="file" name="cover_image" accept="image/*" style="margin-bottom: 20px;">

  <div style="text-align: center;">
    <button type="submit" class="btn">Update Book</button>
  </div>
</form>
