<h2 class="page-title">📚 Add New Book</h2>

<form method="post" action="add_book_process.php" enctype="multipart/form-data" onsubmit="return validateBookForm();">
  <label>Title:</label>
  <input type="text" name="title" id="title" required>

  <label>Author:</label>
  <input type="text" name="author" id="author" required>

  <div style="display: flex; gap: 20px;">
    <div style="flex: 1;">
      <label for="genre">Genre:</label>
      <select name="genre" id="genre" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px;">
        <option value="">-- Select Genre --</option>
        <option value="Fantasy">Fantasy</option>
        <option value="Science Fiction">Science Fiction</option>
        <option value="Fantasy Thriller">Fantasy Thriller</option>
        <option value="Mystery Thriller">Mystery Thriller</option>
        <option value="Dark Fantasy">Dark Fantasy</option>
        <option value="Gothic Fiction">Gothic Fiction</option>
        <option value="Non-Fiction">Non-Fiction</option>
        <option value="Children’s Fiction">Children’s Fiction</option>
        <option value="Sci-Fi Adventure">Sci-Fi Adventure</option>
        <option value="Dystopian Sci-Fi">Dystopian Sci-Fi</option>
      </select>
    </div>

    <div style="flex: 1;">
      <label for="year">Year:</label>
      <input type="number" name="year" id="year" min="1000" max="2025" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px;">
    </div>
  </div>

  <label>Description:</label>
  <textarea name="description" id="description" required
    style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; background-color: #eef6ff;" rows="4"></textarea>

  <label>Cover Image:</label>
  <input type="file" name="cover_image" accept="image/*" style="margin-bottom: 15px;">

  <div style="text-align: center;">
    <button type="submit" class="btn">Add Book</button>
  </div>
</form>

<script>
function validateBookForm() {
  const title = document.getElementById("title").value.trim();
  const author = document.getElementById("author").value.trim();
  const genre = document.getElementById("genre").value;
  const year = document.getElementById("year").value.trim();
  const description = document.getElementById("description").value.trim();

  if (title.length < 2) {
    alert("Title must be at least 2 characters long.");
    return false;
  }

  if (author.length < 2) {
    alert("Author name must be at least 2 characters long.");
    return false;
  }

  if (genre === "") {
    alert("Please select a genre.");
    return false;
  }

  if (!year || isNaN(year) || year < 1000 || year > 2099) {
    alert("Please enter a valid year between 1000 and 2099.");
    return false;
  }

  if (description.length < 10) {
    alert("Description must be at least 10 characters long.");
    return false;
  }

  return true;
}
</script>
