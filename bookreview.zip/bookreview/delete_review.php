<?php
session_start();
require 'db.php';

if (isset($_GET['id']) && isset($_GET['book_id']) && isset($_SESSION['user_id'])) {
  $review_id = $_GET['id'];
  $book_id = $_GET['book_id'];

  //delete review
  $stmt = $conn->prepare("DELETE FROM reviews WHERE review_id = ? AND user_id = ?");
  $stmt->execute([$review_id, $_SESSION['user_id']]);
}

header("Location: index.php?page=book_details&id=$book_id&msg=deleted");
exit;
?>
