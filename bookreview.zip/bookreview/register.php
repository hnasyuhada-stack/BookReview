<?php
session_start();
if (isset($_SESSION['user_id'])) { // Redirect if already logged in
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Register</title>
  <link rel="stylesheet" href="css/style.css">
  <style>

    .page-title {
      text-align: center;
      margin: 40px 0 20px;
      font-size: 28px;
      color: #2c3e50;
    }

    .form-card {
      display: flex;
      align-items: center;
      justify-content: center;
      background: #fff;
      padding: 30px;
      border-radius: 10px;
      max-width: 800px;
      margin: auto;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
      gap: 30px;
      flex-wrap: wrap;
    }

    .form-left img {
      width: 300px;
      border-radius: 8px;
    }

    .form-right {
      flex: 1;
      min-width: 250px;
    }

    .form-right > label {
      font-weight: bold;
      display: block;
      margin-top: 15px;
    }

    .form-right input, .form-right select {
      width: 100%;
      padding: 10px;
      margin-top: 5px;
      border: 1px solid #ccc;
      border-radius: 4px;
      background-color: #eef6ff;
    }

    .password-wrapper {
      position: relative;
      width: 100%;
    }
    .password-wrapper input[type="password"],
    .password-wrapper input[type="text"] {
      width: 100%;
      padding-right: 60px;
      box-sizing: border-box;
    }
    .toggle-password-label {
      position: absolute;
      right: 14px;
      top: 50%;
      transform: translateY(-50%);
      color: #3498db;
      cursor: pointer;
      font-size: 15px;
      user-select: none;
      font-weight: 500;
    }
    .toggle-password-label:hover {
      text-decoration: underline;
    }

    .custom-phone-group .custom-phone-input {
      border: none !important;
      background: transparent !important;
      box-shadow: none;
      border-radius: 8px 0 0 8px;
    }

    .custom-phone-group {
      display: flex;
      align-items: center;
      background: #e9f3ff; 
      border: 1px solid #ccc;
      border-radius: 8px;
      height: 48px;
      width: 100%;
      margin-top: 5px;
      margin-bottom: 20px;
      box-sizing: border-box;
    }

    .custom-phone-code {
      color: #7d7d7d;
      font-size: 18px;
      padding: 0 18px;
      background: transparent;
      height: 100%;
      display: flex;
      align-items: center;
      border-right: 1.5px solid #dedede;
      font-family: inherit;
      box-sizing: border-box;
      border-radius: 8px 0 0 8px;
    }

    .custom-phone-input {
      flex: 1;
      border: none !important;
      outline: none;
      background: transparent !important;
      height: 100%;
      color: #444;
      font-size: 18px;
      padding: 0 14px;
      font-family: inherit;
      border-radius: 0 8px 8px 0;
      box-sizing: border-box;
    }

    .custom-phone-input::placeholder {
      color: #b2b2b2;
      letter-spacing: 1px;
      font-size: 14px;
    }

    .form-right button {
      width: 100%;
      margin-top: 20px;
      background-color: #28a745;
      color: white;
      padding: 10px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    .form-right button:hover {
      background-color: #218838;
    }

    .login-link {
      text-align: center;
      margin-top: 20px;
      font-size: 14px;
    }

    .login-link a {
      color: #007bff;
      text-decoration: none;
    }

    .login-link a:hover {
      text-decoration: underline;
    }

    .error-msg {
      background-color: #f8d7da;
      color: #721c24;
      border: 1px solid #f5c6cb;
      border-radius: 5px;
      padding: 10px 20px;
      max-width: 600px;
      margin: 20px auto;
      font-weight: bold;
      text-align: center;
    }

    .form-right input,
    .form-right select,
    .custom-phone-code,
    .custom-phone-input {
      font-family: Arial, sans-serif !important;
      font-size: 14px;
      color: #333;
    }

    .gender-radio-group {
      display: flex;
      gap: 30px;
      margin: 10px 0 20px 0;
      align-items: center;
    }
    .gender-radio {
      font-weight: normal;
      font-size: 15px;
      display: flex;
      align-items: center;
      gap: 6px;
      cursor: pointer;
    }
    .gender-radio input[type="radio"] {
      accent-color: #28a745;
      margin-right: 4px;
    }

  </style>
</head>
<body>

<?php if (isset($_SESSION['register_error'])): ?>
  <div class="error-msg">
    <?= $_SESSION['register_error'] ?>
  </div>
  <?php unset($_SESSION['register_error']); ?>
<?php endif; ?>

<h2 class="page-title">Create Your Account</h2>
<div class="form-card">
  <div class="form-left">
    <img src="images/bookreview.jpg" alt="Book Review Image">
  </div>
  <div class="form-right">
    <form method="post" action="register_process.php" onsubmit="return validateRegister()">
      <label>Username:</label>
      <input type="text" name="username" id="username" required>

      <label>Email:</label>
      <input type="email" name="email" id="email" required>

      <label>Password:</label>
      <div class="password-wrapper">
        <input type="password" name="password" id="password" required>
        <span id="togglePassword" class="toggle-password-label" onclick="togglePassword()">Show</span>
      </div>

      <label>Gender:</label>
      <div class="gender-radio-group">
        <label class="gender-radio">
          <input type="radio" name="gender" value="Male" id="gender-male" required> Male
        </label>
        <label class="gender-radio">
          <input type="radio" name="gender" value="Female" id="gender-female" required> Female
        </label>
      </div>

      <label for="phone">Phone Number:</label>
      <div class="custom-phone-group">
        <span class="custom-phone-code">+60</span>
        <input
          type="text"
          name="phone"
          id="phone"
          maxlength="10"
          placeholder="1XXXXXXXXX"
          required
          autocomplete="off"
          class="custom-phone-input"
          oninput="formatMYPhone(this)"
        >
      </div>

      <button type="submit">Register</button>
    </form>
    <div class="login-link">
      Already have an account? <a href="login.php">Login here</a>.
    </div>
  </div>
</div>

<script>
//toggle password visibility
function togglePassword() {
  const passwordInput = document.getElementById("password");
  const toggleLabel = document.getElementById("togglePassword");
  if (passwordInput.type === "password") {
    passwordInput.type = "text";
    toggleLabel.textContent = "Hide";
  } else {
    passwordInput.type = "password";
    toggleLabel.textContent = "Show";
  }
}
//allow only digits, max 10
function formatMYPhone(input) {
  let digits = input.value.replace(/\D/g, '').slice(0, 10);
  input.value = digits;
}
//validate form
function validateRegister() {
  const username = document.getElementById("username").value;
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;
  const phone = document.getElementById("phone").value.trim();
  //get gender
  const genderRadios = document.getElementsByName("gender");
  let gender = "";
  for (let i = 0; i < genderRadios.length; i++) {
    if (genderRadios[i].checked) {
      gender = genderRadios[i].value;
      break;
    }
  }
  //validate username
  if (/\d/.test(username)) {
    alert("Username must not contain numbers.");
    return false;
  }
  //validate email
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    alert("Invalid email format.");
    return false;
  }
  //validate password
  const strongPass = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{6,}$/;
  if (!strongPass.test(password)) {
    alert("Weak password. It must be at least 6 characters and include letters, numbers, and symbols like !@#$%.");
    return false;
  }
  //validate gender
  if (!gender) {
    alert("Please select a gender.");
    return false;
  }
  //validate phone
  const phonePattern = /^1\d{8,9}$/;
  if (!phonePattern.test(phone)) {
    alert("Phone number must start with '1' and be 9 or 10 digits long (excluding +60).");
    return false;
  }

  return true;
}
</script>

</body>
</html>
