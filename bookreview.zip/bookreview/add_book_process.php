<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id'])) {
  header("Location: login.php");
  exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $user_id = $_SESSION['user_id'];
  $title = $_POST['title'];
  $author = $_POST['author'];
  $genre = $_POST['genre'];
  $year = $_POST['year'];
  $description = $_POST['description'];

  // handle cover image
  $coverImageName = '';
  if (isset($_FILES['cover_image']) && $_FILES['cover_image']['error'] === UPLOAD_ERR_OK) {
    $coverImageName = basename($_FILES['cover_image']['name']);
    $uploadPath = 'images/covers/' . $coverImageName;
    move_uploaded_file($_FILES['cover_image']['tmp_name'], $uploadPath);
  }

  // insert into database WITH user_id
  $stmt = $conn->prepare("INSERT INTO books (user_id, title, author, genre, year, description, cover_image) VALUES (?, ?, ?, ?, ?, ?, ?)");
  $stmt->execute([$user_id, $title, $author, $genre, $year, $description, $coverImageName]);

  // display success message and redirect
  echo "<script>
    alert('Book added successfully!');
    window.location.href = 'index.php?page=view_books';
  </script>";
  exit;
}
?>
