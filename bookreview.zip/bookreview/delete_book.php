<?php
require 'db.php';

if (isset($_GET['id'])) {
  $book_id = intval($_GET['id']);

  $conn->prepare("DELETE FROM reviews WHERE book_id = ?")->execute([$book_id]);

  //delete the book
  $stmt = $conn->prepare("DELETE FROM books WHERE book_id = ?");
  $stmt->execute([$book_id]);

  //success flag
  header("Location: index.php?page=view_books&deleted=1");
  exit();
}
?>
