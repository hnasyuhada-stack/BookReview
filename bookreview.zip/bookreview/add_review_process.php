<?php
session_start();
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['user_id'])) {
  $user_id = $_SESSION['user_id'];
  $book_id = isset($_POST['book_id']) ? (int)$_POST['book_id'] : 0;
  $rating = isset($_POST['rating']) ? (int)$_POST['rating'] : 0;
  $comment = trim($_POST['comment']);

  // validation
  if ($book_id && $rating >= 1 && $rating <= 5 && $comment !== '') {
    $stmt = $conn->prepare("INSERT INTO reviews (book_id, user_id, rating, comment) VALUES (?, ?, ?, ?)");
    $stmt->execute([$book_id, $user_id, $rating, $comment]);
  }

  header("Location: index.php?page=book_details&id=$book_id&msg=added");
  exit;
}
?>
